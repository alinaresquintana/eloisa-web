window.ERG_ARTWORKS = [
  {
    id: "art-01",
    title: "Nébuleuse en bleu",
    category: "original",
    series: "nebula",
    seriesLabel: {
      fr: "Série Nébuleuses",
      en: "Nebulae Series",
      it: "Serie Nebulose",
      es: "Serie Nebulosas"
    },
    dimensions: "120 × 100 cm",
    medium: {
      fr: "Huile et pigments minéraux sur lin belge",
      en: "Oil & mineral pigments on Belgian linen",
      it: "Olio e pigmenti minerali su lino belga",
      es: "Óleo y pigmentos minerales sobre lino belga"
    },
    year: "2023",
    priceEur: 3200,
    status: "available",
    image: "images/nebuleuse-en-bleu.jpg",
    desc: {
      fr:
        "Une composition cosmique immersive explorant la genèse stellaire et les nuances profondes de bleu.",
      en:
        "An immersive cosmic composition exploring stellar genesis and deep blue hues.",
      it: "Una composizione cosmica immersiva.",
      es:
        "Una composición cósmica inmersiva que explora la génesis estelar en tonos azules."
    }
  },
  {
    id: "art-02",
    title: "Sedimentum Stratum IV",
    category: "original",
    series: "sediment",
    seriesLabel: {
      fr: "Série Sédiments",
      en: "Sediments Series",
      it: "Serie Sedimenti",
      es: "Serie Sedimentos"
    },
    dimensions: "140 × 110 cm",
    medium: {
      fr: "Technique mixte, terres ocres et pigments sur lin",
      en: "Mixed media, raw ochres & pigments on linen",
      it: "Tecnica mista e pigmenti naturali",
      es: "Técnica mixta, tierras ocres y pigmentos sobre lino"
    },
    year: "2023",
    priceEur: 3800,
    status: "available",
    image: "images/sedimentum-iv.jpg",
    desc: {
      fr:
        "Strates géologiques et textures profondes évoquant le passage du temps.",
      en: "Geological strata and deep textures evoking the passage of time.",
      it: "Strati geologici e trame profonde.",
      es:
        "Estratos geológicos y texturas profundas que evocan el paso del tiempo."
    }
  },
  {
    id: "art-03",
    title: "Nebula Genesis: Horizon",
    category: "original",
    series: "nebula",
    seriesLabel: {
      fr: "Série Nébuleuses",
      en: "Nebulae Series",
      it: "Serie Nebulose",
      es: "Serie Nebulosas"
    },
    dimensions: "100 × 80 cm",
    medium: {
      fr: "Huile et pigments naturels sur châssis",
      en: "Oil and raw pigments on canvas",
      it: "Olio e pigmenti su tela",
      es: "Óleo y pigmentos naturales sobre bastidor"
    },
    year: "2023",
    priceEur: 2800,
    status: "available",
    image: "images/nebula-genesis.jpg",
    desc: {
      fr:
        "Fluidité chromatique et dialogue entre obscurité et matière lumineuse.",
      en:
        "Chromatic fluidity and dialogue between darkness and luminous matter.",
      it: "Fluidità cromatica e materia luminosa.",
      es:
        "Fluidez cromática y diálogo entre la oscuridad y la materia luminosa."
    }
  },
  {
    id: "art-04",
    title: "Tectonic Memory & Earth",
    category: "original",
    series: "sediment",
    seriesLabel: {
      fr: "Série Sédiments",
      en: "Sediments Series",
      it: "Serie Sedimenti",
      es: "Serie Sedimentos"
    },
    dimensions: "120 × 60 cm",
    medium: {
      fr: "Technique mixte et résines naturelles",
      en: "Mixed media & natural resins",
      it: "Tecnica mista e resine naturali",
      es: "Técnica mixta y resinas naturales"
    },
    year: "2023",
    priceEur: 2600,
    status: "available",
    image: "images/tectonic-memory.jpg",
    desc: {
      fr: "Panoramique matérique capturant la friction des plaques minérales.",
      en: "Panoramic texture capturing the friction of mineral plates.",
      it: "Panoramica materica.",
      es: "Panorámica matérica que captura la fricción de las placas minerales."
    }
  },
  {
    id: "art-05",
    title: "Sedimentum Quadrata",
    category: "original",
    series: "sediment",
    seriesLabel: {
      fr: "Série Sédiments",
      en: "Sediments Series",
      it: "Serie Sedimenti",
      es: "Serie Sedimentos"
    },
    dimensions: "100 × 100 cm",
    medium: {
      fr: "Pigments de terre, sable et huile sur lin",
      en: "Earth pigments, sand & oil on linen",
      it: "Pigmenti di terra e sabbia su lino",
      es: "Pigmentos de tierra, arena y óleo sobre lino"
    },
    year: "2023",
    priceEur: 3100,
    status: "available",
    image: "images/sedimentum-quadrata.jpg",
    desc: {
      fr:
        "Format carré explorant l'équilibre géométrique au sein du chaos de la terre.",
      en:
        "Square format exploring geometric balance within the chaos of earth.",
      it: "Formato quadrato in equilibrio geometrico.",
      es: "Formato cuadrado que explora el equilibrio geométrico en la tierra."
    }
  },
  {
    id: "art-06",
    title: "Horizontal Sediment (Fine Art Print)",
    category: "print",
    series: "sediment",
    seriesLabel: {
      fr: "Tirage Édition Limitée 1/25",
      en: "Limited Edition Print 1/25",
      it: "Edizione Limitata 1/25",
      es: "Edición Limitada Print 1/25"
    },
    dimensions: "80 × 40 cm",
    medium: {
      fr: "Giclée sur papier coton Hahnemühle 310g",
      en: "Giclée on 310g Hahnemühle cotton paper",
      it: "Giclée su carta cotone",
      es: "Giclée sobre papel de algodón Hahnemühle"
    },
    year: "2023",
    priceEur: 390,
    status: "available",
    image: "images/horizontal-sediment.jpg",
    desc: {
      fr: "Tirage pigmentaire de haute précision numéroté et signé à la main.",
      en: "High-precision archival pigment print, hand numbered and signed.",
      it: "Stampa pigmentare ad alta precisione.",
      es: "Tiraje pigmentario de alta fidelidad numerado y firmado a mano."
    }
  },
  {
    id: "art-07",
    title: "Cosmic Mineral Harmony (Fine Art Print)",
    category: "print",
    series: "nebula",
    seriesLabel: {
      fr: "Tirage Édition Limitée 1/25",
      en: "Limited Edition Print 1/25",
      it: "Edizione Limitata 1/25",
      es: "Edición Limitada Print 1/25"
    },
    dimensions: "75 × 60 cm",
    medium: {
      fr: "Giclée sur papier coton Hahnemühle 310g",
      en: "Giclée on 310g Hahnemühle cotton paper",
      it: "Giclée su carta cotone",
      es: "Giclée sobre papel de algodón Hahnemühle"
    },
    year: "2023",
    priceEur: 420,
    status: "available",
    image: "images/cosmic-harmony.jpg",
    desc: {
      fr:
        "Édition d'art reproduisant les nuances les plus subtiles de la toile originale.",
      en:
        "Fine art edition capturing the most subtle nuances of the original canvas.",
      it: "Edizione d'arte ad altissima definizione.",
      es:
        "Edición de arte que reproduce los matices más sutiles del lienzo original."
    }
  },
  {
    id: "art-08",
    title: "Cosmic Mineral Harmony (Fine Art Print)",
    category: "original",
    series: "prueba",
    seriesLabel: { fr: "prueba", en: "prueba", it: "prueba", es: "prueba" },
    dimensions: "75 × 60 cm",
    medium: {
      fr: "Giclée sur papier coton Hahnemühle 310g",
      en: "Giclée on 310g Hahnemühle cotton paper",
      it: "Giclée su carta cotone",
      es: "Giclée sobre papel de algodón Hahnemühle"
    },
    year: "2023",
    priceEur: 420,
    status: "available",
    image: "images/cosmic-harmony.jpg",
    desc: {
      fr:
        "Édition d'art reproduisant les nuances les plus subtiles de la toile originale.",
      en:
        "Fine art edition capturing the most subtle nuances of the original canvas.",
      it: "Edizione d'arte ad altissima definizione.",
      es:
        "Edición de arte que reproduce los matices más sutiles del lienzo original."
    }
  },
  {
    id: "art-09",
    title: "Milky Way Centre",
    category: "original",
    series: "nebula",
    seriesLabel: {
      fr: "Série Nébuleuses",
      en: "Nebulae Series",
      it: "Serie Nebulose",
      es: "Serie Nebulosas"
    },
    dimensions: "140 × 100 cm",
    medium: {
      fr: "Huile, pigments cosmiques et poudres métalliques sur lin",
      en: "Oil, cosmic pigments & metallic powders on linen",
      it: "Olio, pigmenti cosmici e polveri metalliche su lino",
      es: "Óleo, pigmentos cósmicos y polvos metálicos sobre lino"
    },
    year: "2024",
    priceEur: 3900,
    status: "available",
    image: "images/milky_way_centre.jpg",
    desc: {
      fr:
        "Une immersion vibrante dans le cœur incandescent de la voie lactée, où les magentas profonds et les violets cosmiques dialoguent avec des milliards d'étoiles en suspension.",
      en:
        "A vibrant immersion into the incandescent heart of the Milky Way, where deep magentas and cosmic purples converse with suspended stardust.",
      it: "Un'immersione vibrante nel cuore incandescente della Via Lattea.",
      es:
        "Una inmersión vibrante en el núcleo incandescente de la vía láctea, donde los magentas profundos y púrpuras cósmicos dialogan con polvo estelar en suspensión."
    }
  },
  {
    id: "art-10",
    title: "Eternal Stop",
    category: "original",
    series: "otras",
    seriesLabel: {
      fr: "Série Paysages",
      en: "Landscapes Series",
      it: "Serie Paesaggi",
      es: "Otras obras"
    },
    dimensions: "130 × 95 cm",
    medium: {
      fr: "Huile sur toile",
      en: "Oil on canvas",
      it: "Olio su tela",
      es: "Óleo sobre lienzo"
    },
    year: "2024",
    priceEur: 3400,
    status: "available",
    image: "images/eternal_stop.jpg",
    desc: {
      fr:
        "Une exploration introspective de la solitude contemporaine et de l'immobilité lumineuse sous un ciel infini.",
      en:
        "An introspective exploration of contemporary solitude and luminous stillness under an infinite sky.",
      it: "Un'esplorazione introspettiva della solitudine contemporanea.",
      es:
        "Una exploración introspectiva de la soledad contemporánea y la inmovilidad luminosa bajo un cielo infinito."
    }
  }
];
